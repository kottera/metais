two ../../static/js/b.js
