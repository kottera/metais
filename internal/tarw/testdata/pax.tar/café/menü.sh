#!/bin/sh
echo ok
